/*Además de lo anterior, ahora 
se agregara un temporizador que
 a los cinco segundos dará por terminado 
 el juego  de no ser ingresado el resultado 
 correcto en ese lapso de tiempo. */
var respuesta;
var temporizador;
function comenzar()
{
	
}//FIN DE LA FUNCIÓN
function Responder()
{
	


}//FIN DE LA FUNCIÓN
